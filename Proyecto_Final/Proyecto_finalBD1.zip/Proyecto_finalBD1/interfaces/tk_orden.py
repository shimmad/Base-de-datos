import tkinter as tk
from tkinter import messagebox
from datetime import datetime
from entidades.orden import Orden
from entidades.client import Cliente
from entidades.product import Producto
from Base_datos.connect import BaseDeDatos


db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
db.conectar()
orden_db = Orden(db)
producto_db = Producto(db)
cliente_db = Cliente(db)

#3. Procesamiento de Órdenes: Mostrar las órdenes pedidas por un cliente dado
def mostrar_gestion_ordenes():
    ventana = tk.Toplevel()
    ventana.title("Gestión de Productos") 
    ventana.geometry("400x300")
    ventana.config(bg='yellow') 

    


    tk.Button(ventana, text="Registrar Orden", command=mostrar_crear_orden).pack(pady=5)
    tk.Button(ventana, text="Ver Ordenes por Cliente", command=mostrar_ordenes_por_cliente).pack(pady=5) 
    tk.Button(ventana, text="Cerrar", command=ventana.destroy).pack(pady=10)
    

def mostrar_crear_orden():
    ventana = tk.Toplevel()
    ventana.title("Crear Orden")

    tk.Label(ventana, text="Cliente ID:").grid(row=0, column=0)
    cliente_id_entry = tk.Entry(ventana)
    cliente_id_entry.grid(row=0, column=1)

    tk.Label(ventana, text="Producto ID:").grid(row=1, column=0)
    prod_id_entry = tk.Entry(ventana)
    prod_id_entry.grid(row=1, column=1)

    tk.Label(ventana, text="Cantidad de Unidades:").grid(row=2, column=0)
    cant_unidades_entry = tk.Entry(ventana)
    cant_unidades_entry.grid(row=2, column=1)
    
    tk.Label(ventana, text="Fecha (YYYY-MM-DD):").grid(row=3, column=0)
    fecha_entry = tk.Entry(ventana)
    fecha_entry.grid(row=3, column=1)

    def crear_orden():
        try:
            cliente_id = int(cliente_id_entry.get())
            prod_id = int(prod_id_entry.get())
            cant_unidades = int(cant_unidades_entry.get())
            fecha_str = fecha_entry.get()  # Fecha en formato string
            fecha = datetime.strptime(fecha_str, "%Y-%m-%d").date()  # Convertir a solo la fecha
            
            #Llama a registrar_orden y guarda el resultado
            resultado = orden_db.registrar_orden(fecha, cant_unidades, prod_id, cliente_id)
            messagebox.showinfo("Resultado", resultado)
            ventana.destroy()
            
        except ValueError as e:
            messagebox.showwarning("Entrada inválida", "Por favor, asegúrese de que todos los campos están llenos correctamente.")
        
    tk.Button(ventana, text="Crear Orden", command=crear_orden).grid(row=5, columnspan=2)
    

def mostrar_ordenes_por_cliente():
    ventana = tk.Toplevel()
    ventana.title("Órdenes por Cliente")
    ventana.geometry("500x400")

    # Entrada para buscar el cliente
    tk.Label(ventana, text="ID o Nombre del Cliente:").pack()
    cliente_entry = tk.Entry(ventana)
    cliente_entry.pack()

    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()

    def buscar_ordenes():
        cliente = cliente_entry.get()
        
        if not cliente:
            messagebox.showwarning("Error", "Por favor, ingrese el ID o nombre del cliente.")
            return
        
        
        try:
        
            ordenes = orden_db.buscar_ordenes_por_cliente(cliente)  
            listbox.delete(0, tk.END)  #Limpiar el listbox
            if not ordenes:
                listbox.insert(tk.END, "No se encontraron órdenes para este cliente.")
            else:
                for orden in ordenes:
                    listbox.insert(tk.END, f"Orden #{orden[0]}: {orden[4]} unidades de Producto {orden[2]} (Fecha: {orden[1]})")
        except Exception as e:
            messagebox.showerror("Error", f"Error al buscar las órdenes: {e}")

    tk.Button(ventana, text="Buscar", command=buscar_ordenes).pack()



def cerrar_conexion():
    db.desconectar()
