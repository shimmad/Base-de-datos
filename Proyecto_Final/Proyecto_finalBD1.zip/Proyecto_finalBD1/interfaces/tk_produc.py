import tkinter as tk
from tkinter import messagebox
from entidades.product import Producto
from Base_datos.connect import BaseDeDatos

db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
db.conectar()
producto_db = Producto(db)

#1. Gestión de Productos: Agregar, actualizar, ver o eliminar productos, incluyendo categorías y niveles de stock.
def mostrar_gestion_productos():
    ventana = tk.Toplevel()
    ventana.title("Gestión de Productos")
    ventana.geometry("400x300")
    ventana.config(bg='red')  
    
    tk.Button(ventana, text="Registrar Producto", command=mostrar_registro_producto).pack(pady=5)
    tk.Button(ventana, text="Actualizar Producto", command=mostrar_actualizacion_producto).pack(pady=5)
    tk.Button(ventana, text="Eliminar Producto", command=mostrar_eliminacion_producto).pack(pady=5)
    tk.Button(ventana, text="Ver Productos", command=mostrar_productos).pack(pady=5)
    tk.Button(ventana, text="Cerrar", command=ventana.destroy).pack(pady=10)
        


def mostrar_registro_producto():
    ventana = tk.Toplevel()
    ventana.title("Registrar Producto")
  


    tk.Label(ventana, text="Nombre:").grid(row=0, column=0)
    nombre_entry = tk.Entry(ventana)
    nombre_entry.grid(row=0, column=1)

    tk.Label(ventana, text="Valor:").grid(row=1, column=0)
    valor_entry = tk.Entry(ventana)
    valor_entry.grid(row=1, column=1)

    tk.Label(ventana, text="Stock:").grid(row=2, column=0)
    stock_entry = tk.Entry(ventana)
    stock_entry.grid(row=2, column=1)
    
    tk.Label(ventana, text= "Categoria:").grid(row=3, column=0)
    categoria_entry = tk.Entry(ventana)
    categoria_entry.grid(row=3, column=1)

    def registrar_producto():
        try:
            nombre = nombre_entry.get().strip()
            valor = float(valor_entry.get().strip())
            stock = int(stock_entry.get().strip())
            categoria = categoria_entry.get().strip()
            
            
            validar_campos(nombre,valor,stock,categoria)

            producto_db.registrar_producto(nombre, valor, stock, categoria)
            messagebox.showinfo("Éxito", "Producto registrado con éxito.")
            ventana.destroy()
        except ValueError as e:
            messagebox.showerror("Error en validar", str(e))

    tk.Button(ventana, text="Registrar", command=registrar_producto).grid(row=5, columnspan=2)
    
def mostrar_actualizacion_producto():
    ventana = tk.Toplevel()
    ventana.title("Actualizar Producto")
    ventana.geometry("500x400")

    # Mostrar todos los productos en un Listbox
    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()

    productos = producto_db.ver_productos()  # Asume que esta función devuelve una lista de productos [(prodID, nombre, categoria, stock, precio)]
    for producto in productos:
        listbox.insert(tk.END, f"{producto[0]} - {producto[1]} (Categoría: {producto[2]}, Stock: {producto[3]}, Precio: {producto[4]})")

    def actualizar_producto():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Producto", "Debe seleccionar un producto para actualizar.")
            return
        producto_id = productos[seleccion[0]][0]

        # Obtener los datos actuales del producto
        producto_actual = producto_db.id_producto(producto_id)[0]

        # Ventana para actualizar los datos del producto seleccionado
        actualizacion_ventana = tk.Toplevel()
        actualizacion_ventana.title("Actualizar Datos del Producto")
        actualizacion_ventana.geometry("400x300")

        # Campos para editar
        tk.Label(actualizacion_ventana, text="Nombre:").grid(row=0, column=0)
        nombre_entry = tk.Entry(actualizacion_ventana)
        nombre_entry.insert(0, producto_actual[1])  # Nombre actual
        nombre_entry.grid(row=0, column=1)

        tk.Label(actualizacion_ventana, text="Categoría:").grid(row=1, column=0)
        categoria_entry = tk.Entry(actualizacion_ventana)
        categoria_entry.insert(0, producto_actual[2])  # Categoría actual
        categoria_entry.grid(row=1, column=1)

        tk.Label(actualizacion_ventana, text="Stock:").grid(row=2, column=0)
        stock_entry = tk.Entry(actualizacion_ventana)
        stock_entry.insert(0, str(producto_actual[3]))  # Stock actual
        stock_entry.grid(row=2, column=1)

        tk.Label(actualizacion_ventana, text="Precio:").grid(row=3, column=0)
        precio_entry = tk.Entry(actualizacion_ventana)
        precio_entry.insert(0, str(producto_actual[4]))  # Precio actual
        precio_entry.grid(row=3, column=1)

        # Guardar los cambios
        def guardar_cambios():
            try:
                nombre = nombre_entry.get().strip()
                valor = float(precio_entry.get().strip())
                stock = int(stock_entry.get().strip())
                categoria = categoria_entry.get().strip()
                
                
                validar_campos(nombre,valor,stock,categoria)

                producto_db.registrar_producto(nombre, valor, stock, categoria)
                messagebox.showinfo("Éxito", "Producto registrado con éxito.")
                ventana.destroy()
            except ValueError as e:
                messagebox.showerror("Error en validar", str(e))


        tk.Button(actualizacion_ventana, text="Guardar Cambios", command=guardar_cambios).grid(row=4, columnspan=2)

    tk.Button(ventana, text="Actualizar Producto Seleccionado", command=actualizar_producto).pack()

def mostrar_eliminacion_producto():
    ventana = tk.Toplevel()
    ventana.title("Eliminar Producto")
    ventana.geometry("500x400")
    
    # Mostrar todos los productos en un Listbox
    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()
    
    productos = producto_db.ver_productos()  # Asume que esta función devuelve una lista de productos [(prodID, nombre, categoria, stock, precio)]
    for producto in productos:
        listbox.insert(tk.END, f"{producto[0]} - {producto[1]} (Precio: {producto[2]}, Stock: {producto[3]}, Categoria: {producto[4]})")
        
    def eliminar_producto():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Producto", "Debe seleccionar un producto para eliminar.")
            return
        prod_id = productos[seleccion[0]][0]  # Obtener el ID de la orden seleccionada
        
        # Confirmar la eliminación
        if messagebox.askyesno("Confirmar Eliminación", f"¿Desea eliminar el producto #{prod_id}?"):
            producto_db.eliminar_producto(prod_id)
            messagebox.showinfo("Éxito", "Produto eliminada con éxito.")
            ventana.destroy()
            
    tk.Button(ventana, text="Eliminar Producto Seleccionado", command=eliminar_producto).pack()
    
def mostrar_productos():
    ventana = tk.Toplevel()
    ventana.title("Ver Productos")
    ventana.geometry("500x400")
    
    # Mostrar todos los productos en un Listbox
    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()
    
    productos = producto_db.ver_productos()  # Asume que esta función devuelve una lista de productos [(prodID, nombre, categoria, stock, precio)]
    for producto in productos:
        listbox.insert(tk.END, f"{producto[0]} - {producto[1]} (Precio: {producto[2]}, Stock: {producto[3]}, Categoria: {producto[4]})")
        
    tk.Button(ventana, text="Regresar", command=ventana.destroy).pack()
    



def cerrar_conexion():
    db.desconectar()
    
def validar_campos(nombre, categoria, stock, precio):
    # que los campos no estén vacíos
    if not all([nombre, categoria, stock, precio]):
        raise ValueError("Todos los campos son obligatorios.")

    # Validar que el nombre y apellido solo contengan letras
    if not nombre.isalpha() or not categoria.isalpha():
        raise ValueError("El nombre y la categoria solo deben contener letras.")


    if not stock.isdigit() or not not precio.isdigit():
        raise ValueError("El stock y el precio deben contener solo números.")


