import tkinter as tk
from tkinter import messagebox
from entidades.client import Cliente
from Base_datos.connect import BaseDeDatos


db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
db.conectar()
cliente_db = Cliente(db)
#2. Gestión de Clientes: Registrar, actualizar y ver detalles de clientes, gestionar contactos.
def mostrar_gestion_clientes():
    ventana = tk.Toplevel()
    ventana.title("Gestión de Clientes")
    ventana.geometry("400x300")
    ventana.config(bg='orange')  # Fondo de color lila (lavender)




    tk.Button(ventana, text="Registrar Cliente", command=mostrar_registro_cliente).pack(pady=5)
    tk.Button(ventana, text="Actualizar Cliente", command=mostrar_actualizacion_cliente).pack(pady=5)
    tk.Button(ventana, text="Ver Clientes", command=mostrar_clientes).pack(pady=5)
    tk.Button(ventana, text="Cerrar", command=ventana.destroy).pack(pady=10)

def mostrar_registro_cliente():
    ventana = tk.Toplevel()
    ventana.title("Registrar Cliente")

    tk.Label(ventana, text="Nombre:").grid(row=0, column=0)
    nombre_entry = tk.Entry(ventana)
    nombre_entry.grid(row=0, column=1)

    tk.Label(ventana, text="Apellido:").grid(row=1, column=0)
    apellido_entry = tk.Entry(ventana)
    apellido_entry.grid(row=1, column=1)

    tk.Label(ventana, text="Teléfono:").grid(row=2, column=0)
    telefono_entry = tk.Entry(ventana)
    telefono_entry.grid(row=2, column=1)

    tk.Label(ventana, text="Email:").grid(row=3, column=0)
    email_entry = tk.Entry(ventana)
    email_entry.grid(row=3, column=1)

    tk.Label(ventana, text="Dirección:").grid(row=4, column=0)
    direccion_entry = tk.Entry(ventana)
    direccion_entry.grid(row=4, column=1)

    def registrar_cliente():
        try:
            nombre = nombre_entry.get().strip()
            apellido = apellido_entry.get().strip()
            telefono = telefono_entry.get().strip()
            email = email_entry.get().strip()
            direccion = direccion_entry.get().strip()

            
            validar_campos(nombre, apellido, telefono, email, direccion)

            
            cliente_db.registrar_cliente(nombre, apellido, telefono, email, direccion)
            messagebox.showinfo("Éxito", "Cliente registrado con éxito.")
            ventana.destroy()

        except ValueError as e:
            messagebox.showerror("Error de Validación", str(e))


    tk.Button(ventana, text="Registrar", command=registrar_cliente).grid(row=5, columnspan=2)

def mostrar_actualizacion_cliente():
    ventana = tk.Toplevel()
    ventana.title("Actualizar Cliente")
    ventana.geometry("400x300")

    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()

    clientes = cliente_db.ver_clientes()
    for cliente in clientes:
        listbox.insert(tk.END, f"{cliente[0]} - {cliente[1]} {cliente[2]}")

    def actualizar_cliente():
        seleccion = listbox.curselection()
        if not seleccion:
            messagebox.showwarning("Seleccionar Cliente", "Debe seleccionar un cliente para actualizar.")
            return
        cliente_id = clientes[seleccion[0]][0]

        cliente_actual = cliente_db.id_cliente(cliente_id)[0]

        actualizacion_ventana = tk.Toplevel()
        actualizacion_ventana.title("Actualizar Datos del Cliente")

        tk.Label(actualizacion_ventana, text="Nombre:").grid(row=0, column=0)
        nombre_entry = tk.Entry(actualizacion_ventana)
        nombre_entry.insert(0, cliente_actual[1])
        nombre_entry.grid(row=0, column=1)

        tk.Label(actualizacion_ventana, text="Apellido:").grid(row=1, column=0)
        apellido_entry = tk.Entry(actualizacion_ventana)
        apellido_entry.insert(0, cliente_actual[2])
        apellido_entry.grid(row=1, column=1)

        tk.Label(actualizacion_ventana, text="Teléfono:").grid(row=2, column=0)
        telefono_entry = tk.Entry(actualizacion_ventana)
        telefono_entry.insert(0, cliente_actual[3])
        telefono_entry.grid(row=2, column=1)

        tk.Label(actualizacion_ventana, text="Email:").grid(row=3, column=0)
        email_entry = tk.Entry(actualizacion_ventana)
        email_entry.insert(0, cliente_actual[4])
        email_entry.grid(row=3, column=1)

        tk.Label(actualizacion_ventana, text="Dirección:").grid(row=4, column=0)
        direccion_entry = tk.Entry(actualizacion_ventana)
        direccion_entry.insert(0, cliente_actual[5])
        direccion_entry.grid(row=4, column=1)

        def guardar_cambios():
            try:
                
                nombre = nombre_entry.get().strip()
                apellido = apellido_entry.get().strip()
                telefono = telefono_entry.get().strip()
                email = email_entry.get().strip()
                direccion = direccion_entry.get().strip()

                
                validar_campos(nombre, apellido, telefono, email, direccion)

               
                cliente_db.registrar_cliente(nombre, apellido, telefono, email, direccion)
                messagebox.showinfo("Éxito", "Cliente registrado con éxito.")
                ventana.destroy()

            except ValueError as e:
                messagebox.showerror("Error de Validación", str(e))


        tk.Button(actualizacion_ventana, text="Guardar Cambios", command=guardar_cambios).grid(row=5, columnspan=2)

    tk.Button(ventana, text="Actualizar Cliente Seleccionado", command=actualizar_cliente).pack()

def mostrar_clientes():
    ventana = tk.Toplevel()
    ventana.title("Ver Clientes")
    
    listbox = tk.Listbox(ventana, width=60)
    listbox.pack()

    for cliente in cliente_db.ver_clientes():
        listbox.insert(tk.END, f"{cliente[0]} - {cliente[1]} {cliente[2]}")


def cerrar_conexion():
    db.desconectar()

def validar_campos(nombre, apellido, telefono, email, direccion):
    if not all([nombre, apellido, telefono, email, direccion]):
        raise ValueError("Todos los campos son obligatorios.")

    if not nombre.isalpha() or not apellido.isalpha() or not direccion.isalpha():
        raise ValueError("El nombre, apellido, direccion solo deben contener letras.")

    if not telefono.isdigit() or len(telefono) < 4:
        raise ValueError("El teléfono debe contener solo números y tener al menos 4 dígitos.")



