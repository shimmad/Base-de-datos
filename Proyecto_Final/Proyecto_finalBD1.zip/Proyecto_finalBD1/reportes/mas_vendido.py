from Base_datos.connect import BaseDeDatos
from tkinter import messagebox

def generar_reporte_productos_mas_vendidos():
    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
    db.conectar()

    query = """
    SELECT nombre, SUM(cant_unidades) as total_vendido
    FROM Ordenes
    INNER JOIN Productos ON Ordenes.prodID = Productos.prodID
    GROUP BY nombre
    ORDER BY total_vendido DESC
    LIMIT 1;
    """
    resultado = db.obtener_datos(query)
    db.desconectar()

    if resultado:
        producto, total = resultado[0]
        reporte= f"Producto más vendido: {producto}\nUnidades vendidas: {total}"
    else:
        reporte= "No hay datos suficientes para generar el reporte."
    
    messagebox.showinfo("Reporte", reporte)
