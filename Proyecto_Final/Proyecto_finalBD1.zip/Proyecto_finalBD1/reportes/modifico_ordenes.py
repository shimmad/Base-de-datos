from Base_datos.connect import BaseDeDatos
from tkinter import messagebox, simpledialog
from entidades.product import Producto

def ajustar_cantidad_maxima_producto():
    prod_id = simpledialog.askinteger("Establecer cantidad máxima", "Ingrese el ID del producto:")
    cantidad_max = simpledialog.askinteger("Establecer cantidad máxima", "Ingrese la cantidad máxima permitida:")

    if prod_id is None or cantidad_max is None or cantidad_max <= 0:
        messagebox.showwarning("Entrada inválida", "Debe ingresar un ID de producto y una cantidad máxima válida mayor que cero.")
        return

    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")

    try:
        db.conectar()
        producto = Producto(db)

        #Establecer cantidad maxima
        resultado = producto.establecer_cantidad_maxima(prod_id, cantidad_max)

        messagebox.showinfo("Límite establecido", resultado)

    except Exception as e:
        messagebox.showerror("Error", f"Ocurrió un error: {str(e)}")
    finally:
        db.desconectar()