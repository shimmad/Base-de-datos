from Base_datos.connect import BaseDeDatos
import tkinter as tk
from tkinter import messagebox, simpledialog


def busqueda_avanzada():
   
    ventana_busqueda = tk.Toplevel()
    ventana_busqueda.title("Búsqueda Avanzada")
    ventana_busqueda.geometry("400x300")

   
    tk.Button(ventana_busqueda, text="Productos con ventas superiores a cierto valor", 
              command=productos_superan_valor, width=50).pack(pady=10)

    tk.Button(ventana_busqueda, text="Clientes que han gastado más de cierta cantidad de dinero",
              command=clientes_mayor_gasto, width=50).pack(pady=10)

    tk.Button(ventana_busqueda, text="Productos de una categoría específica",
              command=productos_por_categoria, width=50).pack(pady=10)


    tk.Button(ventana_busqueda, text="Cerrar", command=ventana_busqueda.destroy, width=20).pack(pady=20)


def productos_superan_valor():
    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
    db.conectar()
    valor_minimo = simpledialog.askfloat("Productos con ventas superiores", "Ingrese el valor mínimo para las ventas:")

    if valor_minimo is None:
        return  # Si el usuario cancela, no hace nada

    query = f"""
    SELECT Productos.prodID, Productos.nombre, SUM(Ordenes.cant_unidades) as total_vendido
    FROM Productos
    INNER JOIN Ordenes ON Productos.prodID = Ordenes.prodID
    GROUP BY Productos.prodID
    HAVING total_vendido > {valor_minimo}
    ORDER BY total_vendido DESC;
    """
    resultados = db.obtener_datos(query)
    db.desconectar()

    if resultados:
        reporte = "\n".join([f"{producto[1]}: {producto[2]} unidades vendidas" for producto in resultados])
    else:
        reporte = "No hay productos que cumplan con ese criterio."

    messagebox.showinfo("Resultados", reporte)


def clientes_mayor_gasto():
    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
    db.conectar()
    monto_minimo = simpledialog.askfloat("Clientes con mayor gasto", "Ingrese el monto mínimo:")

    if monto_minimo is None:
        return  

    query = f"""
    SELECT Clientes.cliente_id, Clientes.nombre, Clientes.apellido, SUM(Ordenes.cant_unidades * Productos.valor) as total_gasto
    FROM Clientes
    INNER JOIN Ordenes ON Clientes.cliente_id = Ordenes.cliente_id
    INNER JOIN Productos ON Ordenes.prodID = Productos.prodID
    GROUP BY Clientes.cliente_id
    HAVING total_gasto > {monto_minimo}
    ORDER BY total_gasto DESC;
    """
    resultados = db.obtener_datos(query)
    db.desconectar()

    if resultados:
        reporte = "\n".join([f"{cliente[1]} {cliente[2]}: ${cliente[3]:.2f} gastados" for cliente in resultados])
    else:
        reporte = "No hay clientes que cumplan con ese criterio."

    messagebox.showinfo("Resultados", reporte)


def productos_por_categoria():
    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
    db.conectar()
    categoria = simpledialog.askstring("Productos por categoría", "Ingrese el nombre de la categoría:")

    if not categoria:
        return  

    query = f"""
    SELECT prodID, nombre, valor, stock
    FROM Productos
    WHERE categoria = '{categoria}';
    """
    resultados = db.obtener_datos(query)
    db.desconectar()

    if resultados:
        reporte = "\n".join([f"{producto[1]}: ${producto[2]:.2f}, Stock: {producto[3]}" for producto in resultados])
    else:
        reporte = f"No hay productos disponibles en la categoría '{categoria}'."

    messagebox.showinfo("Resultados", reporte)
