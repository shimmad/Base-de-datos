import tkinter as tk
from tkinter import messagebox, simpledialog
from interfaces.tk_client import mostrar_gestion_clientes
from interfaces.tk_produc import mostrar_gestion_productos
from interfaces.tk_orden import mostrar_gestion_ordenes
from reportes.mas_vendido import generar_reporte_productos_mas_vendidos
from reportes.busqueda_avanzada import busqueda_avanzada
from reportes.modifico_ordenes import ajustar_cantidad_maxima_producto

def main_menu():
    root = tk.Tk()
    root.title("Sistema de Ventas en Línea")
    root.geometry("400x600")  # Tamaño de la ventana
    root.config(bg='lavender')  # Fondo de color lila (lavender)

    # Frame principal para contener todos los elementos
    main_frame = tk.Frame(root, bg='lavender')
    main_frame.pack(fill="both", expand=True)

    # Canvas para dibujo
    canvas = tk.Canvas(main_frame, width=200, height=100, bg='purple')
    canvas.pack(pady=10)  
    canvas.create_oval(100, 10, 180, 80, width=2, fill='pink')
    canvas.create_rectangle(10, 20, 80, 100, width=2, fill='violet')
   
   
    

    tk.Label(main_frame, text="Sistema de Ventas en Línea", font=("Helvetica", 16), bg='light blue').pack(pady=20)

    btn_clientes = tk.Button(main_frame, text="Gestionar Clientes", command=mostrar_gestion_clientes)
    btn_clientes.pack(pady=5)

    btn_productos = tk.Button(main_frame, text="Gestionar Productos", command=mostrar_gestion_productos)
    btn_productos.pack(pady=5)

    btn_ordenes = tk.Button(main_frame, text="Gestionar Órdenes", command=mostrar_gestion_ordenes)
    btn_ordenes.pack(pady=5)
    
    btn_reporte = tk.Button(main_frame, text="Producto mas vendido", command=generar_reporte_productos_mas_vendidos)
    btn_reporte.pack(pady=5)
    
    btn_reporte_frecuentes = tk.Button(main_frame, text="Busqueda avanzada", command=busqueda_avanzada)
    btn_reporte_frecuentes.pack(pady=5)
    
    btn_reporte_ajuste = tk.Button(main_frame, text="Ajustar cantidades", command=ajustar_cantidad_maxima_producto)
    btn_reporte_ajuste.pack(pady=10)

 
    btn_salir = tk.Button(main_frame, text="Salir", command=root.quit)
    btn_salir.pack(pady=5)
        # Canvas para dibujo
    canvas = tk.Canvas(main_frame, width=200, height=100, bg='green')
    canvas.pack(pady=10)  
    canvas.create_oval(170, 80,100, 10, width=2, fill='light green')
    canvas.create_rectangle(80, 100, 10, 22, width=2, fill='light blue')
    
   


    root.mainloop()

if __name__ == "__main__":
    main_menu()
