## Justificación del Diseño de la Base de Datos
### Proyecto: Sistema de Ventas en Línea

El diseño de la base de datos para el proyecto incluye tres entidades principales: Clientes, Productos y Órdenes, siguiendo las especificaciones de la consigna, donde cada orden está asociada a un único producto. Este modelo es suficiente para cumplir los requisitos y está diseñado para alcanzar la Tercera Forma Normal (3NF).

##### Paso 1: Dependencias Funcionales
**Identificación de dependencias funcionales** 
1. *cliente_id -> nombre, apellido, mail, direccion, telefono*

>>Cada cliente tiene un identificador único (cliente_id) que determina sus atributos personales: nombre, apellido, direccion, correo y teléfono.

2. *producto_id -> nombre, categoria, precio, stock, cant_maxima*

>>Cada producto está identificado de manera única por producto_id, lo que permite determinar su nombre, categoría, precio y cantidad en inventario.

3. *orden_id -> cliente_id, producto_id, fecha, cant_unidades*

>>Cada orden tiene un identificador único (orden_id) que identifica al cliente (cliente_id), al producto (producto_id), la fecha de la orden y la cantidad solicitada.

##### Paso 2: Determinación de Claves Candidatas
Claves candidatas para el esquema inicial
Para identificar de manera única cada registro en la tabla inicial, podemos usar:

**orden_id**: Identificador único que garantiza que cada orden sea distinta.
Esta clave cumple con los requisitos para diferenciar cada registro sin ambigüedades.

##### Paso 3: Normalización hacia la Tercera Forma Normal (3NF)
Propuesta de tablas normalizadas
Se divide el esquema original en tres tablas principales para eliminar redundancias y garantizar que todos los atributos no clave dependan únicamente de la clave primaria.

1. **Tabla Ordenes**
>>Almacena los datos relacionados con cada orden específica.

- orden_id (PK): Identificador único de la orden.
- cliente_id (FK): Referencia al cliente que realizó la orden.
- producto_id (FK): Referencia al producto adquirido.
- fecha: Fecha en la que se realizó la orden.
- cant_unidades: Cantidad de unidades compradas.
**Clave primaria: orden_id**

2. **Tabla Clientes**
>>Almacena la información de los clientes.

- cliente_id (PK): Identificador único del cliente.
- nombre: Nombre del cliente.
- apellido: Apellido del cliente.
- mail: Correo electrónico del cliente.
- direccion: direccion de contacto del cliente.
- telefone: telefono del cliente.
**Clave primaria: cliente_id**

3. **Tabla Productos**
>>Almacena los datos de los productos disponibles en el sistema.

- producto_id (PK): Identificador único del producto.
- nombre: Nombre del producto.
- categoria: Categoría del producto.
- Valor: Precio unitario del producto.
- stock: Cantidad disponible en inventario.
- cant_maxima: se puede eastablecer una cantidad maxima de productos por orden.
**Clave primaria: producto_id**


 ##### Ventajas del Diseño
> Simplicidad: El modelo es fácil de entender y administrar
>>Consistencia: La normalización elimina redundancias y evita inconsistencias en los datos.
>>>Cumple con los Requisitos: El diseño está alineado con las especificaciones del proyecto, donde cada orden debe estar asociada a un solo producto. 

###### Observacion
- Este diseño puede ser redudante en que un cliente solo puede generar una orden de un mismo producto, entonces para que un cliente compre disintos productos se deben generar nuevas ordenes segun el producto para el mismo cliente.