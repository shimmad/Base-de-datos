import mysql.connector


class BaseDeDatos:
    def __init__(self, host, user, password, database):
        self.config = {
            "host": host,
            "user": user,
            "password": password,
            "database": database,
        }
        self.conexion = None
        self.cursor = None

    def conectar(self):
        try:
            self.conexion = mysql.connector.connect(**self.config)
            self.cursor = self.conexion.cursor()
            print("Conexión exitosa a la base de datos.")
        except mysql.connector.Error as err:
            print(f"Error al conectar a la base de datos: {err}")
            self.conexion = None
            self.cursor = None

    def desconectar(self):
        if self.cursor:
            self.cursor.close()
        if self.conexion:
            self.conexion.close()

    def ejecutar(self, query, valores=None):
        if not self.cursor:
            raise Exception("La conexión no está activa.")
        self.cursor.execute(query, valores or ())
        self.conexion.commit()

    def obtener_datos(self, query, valores=None):
        if not self.cursor:
            raise Exception("La conexión no está activa.")
        self.cursor.execute(query, valores or ())
        return self.cursor.fetchall()

# borrar
# Prueba la conexión
if __name__ == "__main__":
    db = BaseDeDatos("localhost", "root", "k4non4shi", "basededatosi")
    db.conectar()

    # Opcional: prueba una consulta básica
    try:
        # Verificar tablas en la base de datos
        tablas = db.obtener_datos("SHOW TABLES;")
        print("Tablas en la base de datos:")
        for tabla in tablas:
            print(tabla[0])
        
        # Obtener detalles de la tabla 'Productos'
        columnas = db.obtener_datos("DESCRIBE Productos;")
        print("Atributos de la tabla 'Productos':")
        for columna in columnas:
            print(f"Nombre: {columna[0]}, Tipo: {columna[1]}")
    
    except Exception as e:
        print(f"Error al ejecutar consulta: {e}")
    
    db.desconectar()