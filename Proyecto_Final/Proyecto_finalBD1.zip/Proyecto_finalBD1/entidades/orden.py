class Orden:
    def __init__(self, db):
        self.db = db

   
    def registrar_orden(self, fecha, cant_unidades, prod_id, cliente_id):
        # Verificar si el producto existe
        query_limite = "SELECT cantidad_maxima FROM Productos WHERE prodID = %s"
        resultado = self.db.obtener_datos(query_limite, (prod_id,))
        
        if not resultado:
            return f"El producto con ID {prod_id} no existe."
        
        cantidad_maxima = resultado[0][0]  # Usamos el índice 0 para acceder al primer valor de la tupla

        # Verificar si cantidad_maxima es None, es decir, no tiene límite
        if cantidad_maxima is None:
            return "El producto no tiene un límite de cantidad."
        
        # Validar que la cantidad no exceda el límite
        if cant_unidades > cantidad_maxima:
            return f"La cantidad solicitada ({cant_unidades}) excede el límite permitido ({cantidad_maxima}) para el producto {prod_id}."
        
        # Registrar la orden si pasa la validación
        query = "INSERT INTO Ordenes (fecha, cant_unidades, prodID, cliente_id) VALUES (%s, %s, %s, %s)"
        valores = (fecha, cant_unidades, prod_id, cliente_id)
        
        try:
            self.db.ejecutar(query, valores)
            return "Orden registrada con éxito."
        except Exception as e:
            return f"Error al registrar la orden: {str(e)}"
    def id_orden(self, orden_id):
        query = "SELECT * FROM Ordenes WHERE ordenID = %s"
        return self.db.obtener_datos(query, (orden_id,))

    def buscar_ordenes_por_cliente(self, cliente):
        try:
            cliente_id = int(cliente)
            query = "SELECT * FROM Ordenes WHERE cliente_id = %s"
            return self.db.obtener_datos(query, (cliente_id,))
        except ValueError:
            query = """
            SELECT o.*
            FROM Ordenes o
            JOIN Clientes c ON o.cliente_id = c.cliente_id
            WHERE c.nombre LIKE %s
            """
            valores = (f"%{cliente}%",)
            return self.db.obtener_datos(query, valores)

 