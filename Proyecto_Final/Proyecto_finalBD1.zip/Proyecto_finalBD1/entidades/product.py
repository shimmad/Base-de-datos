class Producto:
    def __init__(self, db):
        self.db = db

    def registrar_producto(self, nombre, valor, stock, categoria, cantidad_maxima=None):
        """
        Registra un nuevo producto con todos sus atributos, incluyendo cantidad_maxima (opcional).
        """
        query = """
        INSERT INTO Productos (nombre, valor, stock, categoria, cantidad_maxima)
        VALUES (%s, %s, %s, %s, %s)
        """
        valores = (nombre, valor, stock, categoria, cantidad_maxima)
        self.db.ejecutar(query, valores)
        return "Producto registrado con éxito."

    def actualizar_producto(self, prod_id, nombre=None, valor=None, stock=None, categoria=None, cantidad_maxima=None):
        """
        Actualiza uno o varios atributos de un producto existente.
        Solo se actualizan los valores que no son None.
        """
        campos = []
        valores = []

        if nombre is not None:
            campos.append("nombre=%s")
            valores.append(nombre)
        if valor is not None:
            campos.append("valor=%s")
            valores.append(valor)
        if stock is not None:
            campos.append("stock=%s")
            valores.append(stock)
        if categoria is not None:
            campos.append("categoria=%s")
            valores.append(categoria)
        if cantidad_maxima is not None:
            campos.append("cantidad_maxima=%s")
            valores.append(cantidad_maxima)
        
        if not campos:
            return "No se especificaron campos para actualizar."

        query = f"UPDATE Productos SET {', '.join(campos)} WHERE prodID=%s"
        valores.append(prod_id)
        self.db.ejecutar(query, tuple(valores))
        return "Producto actualizado con éxito."

    def id_producto(self, prod_id):
        """
        Devuelve toda la información de un producto por su ID, incluyendo cantidad_maxima.
        """
        query = "SELECT * FROM Productos WHERE prodID = %s"
        return self.db.obtener_datos(query, (prod_id,))
    
    def eliminar_producto(self, prod_id):
        """
        Elimina un producto por su ID.
        """
        query = "DELETE FROM Productos WHERE prodID = %s"
        self.db.ejecutar(query, (prod_id,))
        return "Producto eliminado con éxito."
    
    def ver_productos(self):
        """
        Retorna todos los productos registrados, incluyendo cantidad_maxima.
        """
        query = "SELECT * FROM Productos"
        return self.db.obtener_datos(query)
    
    def buscar_producto_por_nombre(self, nombre):
        """
        Busca productos por nombre (o parte del nombre), incluyendo cantidad_maxima.
        """
        query = "SELECT * FROM Productos WHERE nombre LIKE %s"
        valores = (f"%{nombre}%",)
        return self.db.obtener_datos(query, valores)
    
    def establecer_cantidad_maxima(self, prod_id, cantidad_maxima):
            # Validar que el producto exista
            query_validar = "SELECT * FROM Productos WHERE prodID = %s"
            producto = self.db.obtener_datos(query_validar, (prod_id,))
            if not producto:
                return f"El producto con ID {prod_id} no existe."

            # Actualizar el límite
            query_actualizar = "UPDATE Productos SET cantidad_maxima = %s WHERE prodID = %s"
            self.db.ejecutar(query_actualizar, (cantidad_maxima, prod_id))
            return f"Cantidad máxima para el producto {prod_id} actualizada a {cantidad_maxima}."